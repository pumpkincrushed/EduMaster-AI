"""EduMaster AI — Database package"""
