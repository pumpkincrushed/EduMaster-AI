"""EduMaster AI — Tests package"""
