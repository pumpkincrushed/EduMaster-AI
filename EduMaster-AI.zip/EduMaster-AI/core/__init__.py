"""EduMaster AI — Core package"""
